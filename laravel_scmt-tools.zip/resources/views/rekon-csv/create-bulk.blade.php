@extends('layout')

@section('body')
    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <div class="row align-items-center">
                        {{-- breadcrumb --}}
                        <div class="col-md-8">
                            <h4 class="page-title mb-0">Bulk Upload CSV</h4>
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="#">SCMT UI</a></li>
                                <li class="breadcrumb-item"><a href="#">Rekon CSV</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Bulk Upload CSV</li>
                            </ol>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="alert alert-success bg-success text-white" role="alert" style="display:none;">
                                    <strong id="success-message"></strong>
                                </div>
                                
                                <div class="alert alert-warning bg-warning text-white" role="alert" style="display:none;">
                                    <strong id="error-message"></strong>
                                </div>
                            </div>
                            <div class="col-lg-6 text-right">
                                <form id="form-bulk" action="http://scmt-tools-api-scmt.apps.osh.telkom.co.id/service-detail/insert" method="post" enctype="multipart/form-data" required="" onsubmit="return ajaxSubmit(this, event)"/>
                                    <label for="">Pick CSV file...</label>
                                    <input type="file" accept=".csv" name="csv" placeholder="CSV File..."/>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="card-body table-responsive" style="overflow:scroll">

                        <table class="table table-bordered table-striped" id="tb_rekon">              
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>CATEGORY</th>
                                    <th>BRAND</th>
                                    <th>PRODUCT_TYPE</th>
                                    <th>SERVICE_GROUP</th>
                                    <th>SLG</th>
                                    <th>NAMA_MITRA</th>
                                    {{-- <th>ATTRIBUTE_07</th> --}}
                                    {{-- <th>ATTRIBUTE_08</th> --}}
                                    {{-- <th>ATTRIBUTE_09</th> --}}
                                    {{-- <th>ATTRIBUTE_10</th> --}}
                                    {{-- <th>ASSET_NUMBER</th> --}}
                                    <th>SERIAL_NO</th>
                                    <th>INSTALL_DATE</th>
                                    <th>CONTRACT_START_DATE</th>
                                    <th>CONTRACT_END_DATE</th>
                                    <th>SERVICE_START_DATE</th>
                                    <th>SERVICE_END_DATE</th>
                                    <th>SERVICE_PRICE</th>
                                    <th>SERVICE_PRICE_UNIT</th>
                                    <th>SERVICE_PRICE_PERIOD</th>
                                    {{-- <th>REMARK_01</th> --}}
                                    {{-- <th>REMARK_02</th> --}}
                                    <th>CUSTOMER_CODE</th>
                                    <th>CUSTOMER_NAME</th>
                                    <th>SERVICE_ID</th>
                                    <th>NAMA_LOKASI</th>
                                    <th>LATITUDE</th>
                                    <th>LONGITUDE</th>
                                    <th>WORKZONE</th>
                                    <th>STATUS_CUSTLOC</th>
                                    <th>STATUS_SERVICEDETAIL</th>
                                    {{-- <th>REQUEST_CUSTLOC</th> --}}
                                    {{-- <th>RESPONSE_CUSTLOC</th> --}}
                                    {{-- <th>REQUEST_SERVICEDETAIL</th> --}}
                                    {{-- <th>RESPONSE_SERVICEDETAIL</th> --}}
                                    {{-- <th>EXT_ORDER_NO</th> --}}
                                    {{-- <th>NOMOR_KB</th> --}}
                                    {{-- <th>NOMOR_KL</th> --}}
                                    {{-- <th>OBL_TRC_NO</th> --}}
                                    {{-- <th>SUPPLIER_CODE</th> --}}
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                            <tfoot>
                            </tfoot>					    
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div id="notifications"></div>
@endsection

@push('scripts')
    <script>
        function notifyX(titleXX,msgXX,typeXX){
            $.notify(
                {
                    title: '<h4>'+titleXX+'</h4>',
                    message: msgXX
                },
                {
                    allow_dismiss: true,
                    delay: 0,
                    placement: {
                        from: 'bottom',
                        align: 'right'
                    },	
                    type: typeXX
                }
            );
    
            $('.fadeInDown').click(function() {	
                $(this).remove();
            });
            
            $('.fadeInDown').fadeOut( 10000, function() {	
                $(this).remove();
            });
        }

        $(document).ready(() => {
            setTable();
        });
        
        function setTable(){
            
            var table = $('#tb_rekon').DataTable();
            table.destroy();
            
            table = $('#tb_rekon').DataTable({
                "serverSide": true,
                // "processing": true,
                "scrollX": true,
                "retrieve": true,
                "fixedColumns":   {leftColumns: 3},
                "columnDefs": [
                    //{"targets": [0],"width": "1%", "searchable": false, "orderable": true, "visible": true},
                    //{"targets": [1,2],"width": "150px", "searchable": true, "orderable": true, "visible": true},
                    {"className": "dt-center","targets":"_all" },
                    {"className": "center","targets":"_all" }
                ],
                "ajax": "http://scmt-tools-api-scmt.apps.osh.telkom.co.id/service-detail-datatable",
                "columns": [
                    { "data" : "ID" },
                    { "data" : "CATEGORY" },
                    { "data" : "BRAND" },
                    { "data" : "PRODUCT_TYPE" },
                    { "data" : "SERVICE_GROUP" },
                    { "data" : "SLG" },
                    { "data" : "NAMA_MITRA" },
                    // { "data" : "ATTRIBUTE_07" },
                    // { "data" : "ATTRIBUTE_08" },
                    // { "data" : "ATTRIBUTE_09" },
                    // { "data" : "ATTRIBUTE_10" },
                    // { "data" : "ASSET_NUMBER" },
                    { "data" : "SERIAL_NO" },
                    { "data" : "INSTALL_DATE" },
                    { "data" : "CONTRACT_START_DATE" },
                    { "data" : "CONTRACT_END_DATE" },
                    { "data" : "SERVICE_START_DATE" },
                    { "data" : "SERVICE_END_DATE" },
                    { "data" : "SERVICE_PRICE" },
                    { "data" : "SERVICE_PRICE_UNIT" },
                    { "data" : "SERVICE_PRICE_PERIOD" },
                    // { "data" : "REMARK_01" },
                    // { "data" : "REMARK_02" },
                    { "data" : "CUSTOMER_CODE" },
                    { "data" : "CUSTOMER_NAME" },
                    { "data" : "SERVICE_ID" },
                    { "data" : "NAMA_LOKASI" },
                    { "data" : "LATITUDE" },
                    { "data" : "LONGITUDE" },
                    { "data" : "WORKZONE" },
                    { "data" : "STATUS_CUSTLOC" },
                    { "data" : "STATUS_SERVICEDETAIL" },
                    // { "data" : "REQUEST_CUSTLOC" },
                    // { "data" : "RESPONSE_CUSTLOC" },
                    // { "data" : "REQUEST_SERVICEDETAIL" },
                    // { "data" : "RESPONSE_SERVICEDETAIL" },
                    // { "data" : "EXT_ORDER_NO" },
                    // { "data" : "NOMOR_KB" },
                    // { "data" : "NOMOR_KL" },
                    // { "data" : "OBL_TRC_NO" },
                    // { "data" : "SUPPLIER_CODE" },
                ],
               "dom" : 'lBfrtip',
                //"bPaginate": true,
                //"sPaginationType": "full_numbers",
                //"ordering"  : true,
                //"bInfo"     : false,
                //"bFilter"   : true,
                "paging"      : true,
                //"lengthChange": true,
                "searching"   : true,
                "ordering"    : true,
                "info"        : true,
                "autoWidth"   : true,
                "buttons"   : [
                    {
                        extend  : 'collection',
                        text    : 'Export',
                        buttons : [
                            'copy',
                            'excel',
                            'pdf',
                            'csv'
                        ]
                    },
                ],
            });
            
            //Notify("table refreshed", null, null, 'success');
        }

        function ajaxSubmit(source, event){
            event.preventDefault();

            var form = $(source);
            $.ajax({
                url         : form.attr('action'),
                type        : 'POST',
                data        : new FormData(source),
                processData : false,
                contentType : false,
                success     : (response, xhr) => {
                    $('.alert').hide();
                    if(xhr === 'success'){
                        $('.alert-success').show();
                        $('#success-message').text(response);

                        setTable();
                    } else {
                        $('.alert-warning').show();
                        $('#error-message').text(response);
                        console.log(response);
                    }

                    setTimeout(() => {
                        $('.alert').hide();
                    }, 3000);
                }
            });
        }
        
    </script>
@endpush
