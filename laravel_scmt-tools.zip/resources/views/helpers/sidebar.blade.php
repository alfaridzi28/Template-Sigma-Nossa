{{-- sidebar --}}
<div class="left side-menu">
    <div class="slimscroll-menu" id="remove-scroll">

        <div id="sidebar-menu">
            @if (\Str::contains(auth()->user()->module, ['all', 'user']))
                <ul class="metismenu">
                    <li class="menu-title">User Management</li>
                    <li><a href="{{ route('user.index') }}" class="waves-effect"><i class="dripicons-search"></i> <span> List User </span></a></li>
                    <li><a href="{{ route('user.create') }}" class="waves-effect"><i class="dripicons-document-edit"></i> <span> Create User </span></a></li>
                </ul>
            @endif     

            @if (\Str::contains(auth()->user()->module, ['all', 'search-item']))
                <ul class="metismenu">
                    <li class="menu-title">Search Item</li>
                    <li><a href="{{ route('search-item.by-asset-number') }}" class="waves-effect"><i class="dripicons-search"></i> <span> by Asset Number </span></a></li>
                    <li><a href="{{ route('search-item.by-service-id') }}" class="waves-effect"><i class="dripicons-search"></i> <span> by Service ID </span></a></li>
                    <li><a href="{{ route('search-item.by-wildcard') }}" class="waves-effect"><i class="dripicons-search"></i> <span> by Wildcard </span></a></li>
                </ul>
            @endif            

            @if (\Str::contains(auth()->user()->module, ['all', 'obl']))
                <ul class="metismenu">
                    <li class="menu-title">OBL</li>
                    <li><a href="{{ route('obl.update-service-details') }}" class="waves-effect"><i class="dripicons-document-edit"></i> <span> Update Service Details </span></a></li>
                    <li><a href="{{ route('obl.clear-service-details') }}" class="waves-effect"><i class="dripicons-document-delete"></i> <span> Clear Service Details </span></a></li>
                </ul>
            @endif
            
            @if (\Str::contains(auth()->user()->module, ['all', 'customer-location']))
                <ul class="metismenu">
                    <li class="menu-title">Customer Location</li>
                    {{-- <li><a href="{{ route('rekon-csv.view') }}" class="waves-effect"><i class="dripicons-search"></i> <span> View Rekon CSV </span></a></li> --}}
                    <li><a href="{{ route('customer-location.manage') }}" class="waves-effect"><i class="dripicons-document-edit"></i> <span> Manage Customer Location </span></a></li>
                </ul>
            @endif
            

            @if (\Str::contains(auth()->user()->module, ['all', 'rekon-csv']))
                <ul class="metismenu">
                    <li class="menu-title">Rekon CSV</li>
                    <li><a href="{{ route('rekon-csv.view') }}" class="waves-effect"><i class="dripicons-search"></i> <span> View Rekon CSV </span></a></li>
                    <li><a href="{{ route('rekon-csv.manage') }}" class="waves-effect"><i class="dripicons-document-edit"></i> <span> Manage Rekon CSV </span></a></li>
                    <li><a href="{{ route('rekon-csv.view-bulk') }}" class="waves-effect"><i class="dripicons-document-edit"></i> <span> Bulk Upload CSV </span></a></li>
                </ul>
            @endif

            {{-- <ul class="metismenu">
                <li class="menu-title">Example Files</li>
                <li><a href="{{ Storage::url('wfm-csv-file-example.csv') }}" class="waves-effect"><i class="dripicons-download" download></i> <span> WFM SCV File </span></a></li>
            </ul> --}}
        </div>

        <div class="clearfix"></div>

    </div>
</div>
