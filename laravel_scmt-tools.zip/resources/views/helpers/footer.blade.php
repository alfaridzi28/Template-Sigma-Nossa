<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                © 2019 - 2020 SCMT <span class="d-none d-md-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i></span>
            </div>
        </div>
    </div>
</footer>
