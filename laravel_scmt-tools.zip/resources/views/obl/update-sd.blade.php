@extends('layout')

@section('body')
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="row align-items-center">
                    {{-- breadcrumb --}}
                    <div class="col-md-8">
                        <h4 class="page-title mb-0">OBL - Update Service Details</h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="#">SCMT UI</a></li>
                            <li class="breadcrumb-item"><a href="#">OBL</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Update Service Details</li>
                        </ol>
                    </div>

                    {{-- <div class="col-md-4">
                        <div class="float-right d-none d-md-block">
                            <div class="dropdown">
                                <button class="btn btn-primary btn-rounded dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="ti-settings mr-1"></i> Settings
                                </button>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </div>
                    </div> --}}
                </div>
                
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                {{-- <div class="card-header">
                    
                </div> --}}
                <div class="card-body">

                    <form action="http://10.6.3.135:8028/updateServiceDetails" method="post">

                        @php($names = [
                            "service_id",
                            "asset_number",
                            "ext_order_no_upd",
                            "nomor_kb_upd",
                            "nomor_kl_upd",
                            "obl_trc_no_upd",
                            "service_id_upd",
                            "supplier_code_upd",
                            "category_upd",
                            "brand_upd",
                            "product_type_upd",
                            "service_group_upd",
                            "attribute_05_upd",
                            "attribute_06_upd",
                            "attribute_07_upd",
                            "attribute_08_upd",
                            "attribute_09_upd",
                            "attribute_10_upd",
                            "asset_number_upd",
                            "serial_no_upd",
                            "install_date_upd",
                            "contract_start_date_upd",
                            "contract_end_date_upd",
                            "service_start_date_upd",
                            "service_end_date_upd",
                            "service_price_upd",
                            "service_price_period_upd",
                            "service_price_unit_upd",
                            "remark_01_upd",
                            "remark_02_upd"])

                        @foreach ($names as $name)
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">{{ strtoupper($name) }}</label>
                            <div class="col-sm-9">
                                <input name="{{ $name }}" class="form-control" type="text" placeholder="{{ $name }}" {{ $loop->index == 0 ? 'autofocus = ""' : '' }}>
                            </div>
                        </div>
                        @endforeach

                        <div class="form-group row">
                            <div class="col-sm-10 offset-sm-3">
                                <button type="submit" class="btn btn-primary">Update</button>

                                <br/><br/>
                                <div class="alert text-white" role="alert" style="display:none;">
                                    <strong id="message"></strong>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

</div>
@endsection

@push('scripts')
    <script>
        $(document).ready(() => {
            $('form').submit((e) => {
                $('.alert').hide();
                e.preventDefault();

                var form    = $(e.target),
                    url     = form.attr('action'),
                    data    = form.serialize(),
                    type    = form.attr('method');

                $.ajax({
                    url     : url, 
                    data    : data,
                    type    : type,
                    success : (response) => {
                        $('.alert').removeClass('alert-danger alert-warning alert-success bg-danger bg-warning bg-success').addClass('alert-success bg-success').show();
                        $('#message').text(response.message);

                        setTimeout(() => {
                            $('.alert').hide();
                        }, 5000);
                    },
                    error   : (response) => {
                        if(response.status === 422){
                            $('.alert').removeClass('alert-danger alert-warning alert-success bg-danger bg-warning bg-success').addClass('alert-warning bg-warning').show();
                                $('#message').text(response.responseJSON.message);
                        } else {
                            $('.alert').removeClass('alert-danger alert-warning alert-success bg-danger bg-warning bg-success').addClass('alert-danger bg-danger').show();
                            $('#message').text(response.responseJSON.message);
                        }

                        setTimeout(() => {
                            $('.alert').hide();
                        }, 5000);
                    }
                });
            });
        });
    </script>
@endpush
