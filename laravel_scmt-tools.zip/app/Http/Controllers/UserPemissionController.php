<?php

namespace App\Http\Controllers;

use App\UserPemission;
use Illuminate\Http\Request;

class UserPemissionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\UserPemission  $userPemission
     * @return \Illuminate\Http\Response
     */
    public function show(UserPemission $userPemission)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UserPemission  $userPemission
     * @return \Illuminate\Http\Response
     */
    public function edit(UserPemission $userPemission)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UserPemission  $userPemission
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserPemission $userPemission)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UserPemission  $userPemission
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserPemission $userPemission)
    {
        //
    }
}
