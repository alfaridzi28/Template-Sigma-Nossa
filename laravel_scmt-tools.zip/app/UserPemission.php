<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPemission extends Model
{
    protected $guarded = ['id'];
}
