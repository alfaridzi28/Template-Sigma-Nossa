<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return redirect()->route('search-item.by-asset-number');
});

/* User Management */
Route::group([], function(){
    Route::get('/users'             , 'UserController@index')   ->name('user.index');
    Route::get('/user-create'       , 'UserController@create')  ->name('user.create');
    Route::get('/user-edit/{user}'  , 'UserController@edit')    ->name('user.edit');

    Route::post('/user-store'       , 'UserController@store')    ->name('user.store');
    Route::put('/user-update/{user}', 'UserController@update')    ->name('user.update');

    Route::get('login'              , 'UserController@login')   ->name('login');
    Route::get('logout'             , 'UserController@logout')  ->name('logout');
    Route::post('user-auth'         , 'UserController@auth')    ->name('user.auth');
});

/* Search Item */
Route::group(['middleware' => 'auth'], function(){
    Route::get('/searchitem-by-asset-number'    , 'SearchItemController@byAssetNumber') ->name('search-item.by-asset-number');
    Route::get('/searchitem-by-service-id'      , 'SearchItemController@byServiceID')   ->name('search-item.by-service-id');
    Route::get('/searchitem-by-wildcard'        , 'SearchItemController@byWildcard')    ->name('search-item.by-wildcard');
});

/* OBL */
Route::group(['middleware' => 'auth'], function(){
    Route::get('/obl-update-service-details'    , 'OblController@updateSD')             ->name('obl.update-service-details');
    Route::get('/obl-clear-service-details'     , 'OblController@clearSD')              ->name('obl.clear-service-details');
});

/* Customer Location */
Route::group(['middleware' => 'auth'], function(){
    Route::get('/customer-location-manage'      , 'CustomerController@create')          ->name('customer-location.manage');
});

/* Rekon CSV */
Route::group(['middleware' => 'auth'], function(){
    Route::get('/rekon-csv-manage'              , 'RekonController@manageRekon')        ->name('rekon-csv.manage');
    Route::get('/rekon-csv-view'                , 'RekonController@viewRekon')          ->name('rekon-csv.view');
    Route::get('/rekon-csv-bulk'                , 'RekonController@viewRekonBulk')      ->name('rekon-csv.view-bulk');
    Route::post('/rekon-csv-post'               , 'RekonController@postRekon')          ->name('rekon-csv.post');
});
