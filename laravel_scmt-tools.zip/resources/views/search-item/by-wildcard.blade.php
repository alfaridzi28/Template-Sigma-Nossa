@extends('layout')

@section('body')
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="row align-items-center">
                    {{-- breadcrumb --}}
                    <div class="col-md-8">
                        <h4 class="page-title mb-0">Search Item By Wildcard</h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="#">SCMT UI</a></li>
                            <li class="breadcrumb-item"><a href="#">Search Item</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Search By Wildcard</li>
                        </ol>
                    </div>

                    {{-- <div class="col-md-4">
                        <div class="float-right d-none d-md-block">
                            <div class="dropdown">
                                <button class="btn btn-primary btn-rounded dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="ti-settings mr-1"></i> Settings
                                </button>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Separated link</a>
                                </div>
                            </div>
                        </div>
                    </div> --}}
                </div>
                
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="alert alert-warning bg-warning text-white" role="alert" style="display:none;">
                        <strong id="error-message"></strong>
                    </div>

                    <form action="http://10.6.3.135:8026/searchItemByWildCard" method="get">
                        <div class="form-group row">

                            <label class="col-sm-2 col-form-label text-right">Customer Code</label>
                            <div class="col-sm-3">
                                <input name="customer_code" class="form-control" type="text" placeholder="Customer Code" required="" autofocus="true">
                            </div>

                            <label class="col-sm-2 col-form-label text-right">Asset Number</label>
                            <div class="col-sm-3">
                                <input name="asset_number" class="form-control" type="text" placeholder="Asset Number" required="">
                            </div>

                            <div class="col-sm-2 text-right">
                                <button id="submit" type="submit" class="btn btn-primary">Search</button>
                                {{-- <button id="next"   type="button" class="btn btn-secondary" onclick="fetchNext();" style="display:none;">Next</button> --}}
                            </div>

                            <input id="from"    name="from" type="hidden" value="1">
                            <input id="to"      name="to"   type="hidden" value="10">
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    {{-- <h4 class="mt-0 header-title">Basic example</h4>
                    <p class="text-muted m-b-30 font-14">For basic styling—light padding and
                        only horizontal dividers—add the base class <code>.table</code> to any
                        <code>&lt;table&gt;</code>.
                    </p> --}}
                    <div class="row">
                        <div class="col-sm-6">
                            <h5>Total records : <strong id="total-records"></strong> </h5>
                        </div>
                        <div class="col-sm-6">
                            <ul class="pagination pull-right"></ul>
                        </div>
                    </div>

                    <div class="row" style="overflow:scroll">
                        <div class="col-sm-12">
                            <table class="table table-bordered table-condensed table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Waiting...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Please provide Customer Code and Asset Number</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection

@push('scripts')
    <script>
        var pageOffset = 1;

        $(document).ready(() => {
            $('form').submit((e) => {               

                $('.alert').hide();
                e.preventDefault();

                var form    = $(e.target),
                    url     = form.attr('action'),
                    data    = form.serialize(),
                    type    = form.attr('method');

                // $('thead').html('<tr><td>-</td></tr>')
                var colspan = $('thead tr th').length + 1 ;
                $('tbody').html(`<tr><td align="center" colspan="${colspan}">-</td></tr>`);
                $.ajax({
                    url     : url, 
                    data    : data,
                    type    : type,
                    success : (response) => {
                        // $('#submit').hide();
                        // $('#next').show();

                        var body            = ``,
                            fillHeader      = true,
                            header          = ``,
                            row             = (10 * pageOffset),
                            rowCount        = 9;
                            totalRecords    = 0;

                        for(var entity of response.body.details){
                            body    += "<tr>";
                            header  += "<tr>";
                                
                            if(fillHeader) header  += "<td>#</td>";
                            body    += `<td>${(row - rowCount)}</td>`;
                            rowCount--;

                            for(var key in entity){
                                if(key === 'TTL_RECORD'){
                                    totalRecords = parseInt(entity[key]);
                                } else {
                                    if(fillHeader)  header  += `<th><strong>${key}</strong></th>`;
                                    body    += `<td>${entity[key]}</td>`;
                                }
                            }

                            body    += "</tr>";
                            header  += "</tr>";

                            fillHeader = false;
                        }

                        $('thead').html(header);
                        $('tbody').html(body);
                        $('#total-records').text(totalRecords);

                        $('.pagination').twbsPagination({
                            initiateStartPageClick  : false,
                            totalPages              : parseInt(Math.ceil(totalRecords / 10)),
                            visiblePages            : 10,
                            onPageClick             : (event, page) => {
                                pageOffset = page;
                                $('#from').val((10 * page) - 9);
                                $('#to').val(10 * page);
                                $('#submit').click();
                            }
                        });
                    },
                    error   : (response) => {
                        if(response.status === 422){
                            $('.alert').show();
                            $('#error-message').text(response.responseJSON.message);

                            $('#total-records').text('');
                            $('thead').html(`<tr><th>-</th></tr>`);
                            $('tbody').html(`<tr><th>No data found</th></tr>`);
                            $('.pagination').html('');

                            setTimeout(() => {
                                $('.alert').hide();
                            }, 5000)
                        } else {
                            console.log(response);
                        }
                    }
                });
            });
        });
    </script>
@endpush
