@extends('layout')

@section('body')
<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="row align-items-center">
                    {{-- breadcrumb --}}
                    <div class="col-md-8">
                        <h4 class="page-title mb-0">Manage Rekon CSV</h4>
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="#">SCMT UI</a></li>
                            <li class="breadcrumb-item"><a href="#">Rekon CSV</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Manage</li>
                        </ol>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    @if (\Session::has('message'))
                    <div class="alert alert-success bg-success text-white" role="alert">
                        <strong>Rekon CSV submitted successfully</strong>
                    </div>
                    @endif
                </div>
                <div class="card-body">

                    <h4 class="mt-0 header-title">Please fill all the forms below</h4>
                    <form id="form-rekon" action="{{ route('rekon-csv.post') }}" method="post" enctype="multipart/form-data">
                        @method('post')
                        @csrf

                        {{-- WONUM --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">WO Number</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="WONUM" placeholder="WO Number" value="{{ old('WONUM', '') }}" required="">
                            </div>
                        </div>

                        {{-- DOCNAME --}}
                        <div class="form-group row" style="display:none">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Doc Name</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="DOCNAME" placeholder="DOC Name" value="SERVICE_DETAIL" required="">
                            </div>
                        </div>

                        {{-- ATTACHMENT (URL) --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Attachment</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="file" name="ATTACHMENT" placeholder="Attachment">
                            </div>
                        </div>

                        {{-- EXT_ORDER_NO --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Ext Order No</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="EXT_ORDER_NO" placeholder="Ext Order No" value="{{ old('EXT_ORDER_NO', '') }}" required="">
                            </div>
                        </div>

                        {{-- NOMOR_KB --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Nomor KB</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="NOMOR_KB" placeholder="Nomor KB" value="{{ old('NOMOR_KB', '') }}" required="">
                            </div>
                        </div>

                        {{-- NOMOR_KL --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Nomor KL</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="NOMOR_KL" placeholder="Nomor KL" value="{{ old('NOMOR_KL', '') }}" required="">
                            </div>
                        </div>

                        {{-- OBL_TRC_NO --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">OBL TRC No</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="OBL_TRC_NO" placeholder="OBL TRC No" value="{{ old('OBL_TRC_NO', '') }}" required="">
                            </div>
                        </div>

                        {{-- SERVICE_ID --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Service ID</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="SERVICE_ID" placeholder="Service ID" value="{{ old('SERVICE_ID', '') }}" required="">
                            </div>
                        </div>

                        {{-- SUPPLIER_CODE --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Supplier Code</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="SUPPLIER_CODE" placeholder="Supplier Code" value="{{ old('SUPPLIER_CODE', '') }}" required="">
                            </div>
                        </div>

                        {{-- NAMA_MITRA --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Nama Mitra</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="NAMA_MITRA" placeholder="Nama Mitra" value="{{ old('NAMA_MITRA', '') }}" required="">
                            </div>
                        </div>

                        {{-- INSTALL_DATE --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Install Date</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" name="INSTALL_DATE" placeholder="yyyymmddhhiiss" value="{{ old('INSTALL_DATE', '') }}" required="">
                            </div>
                        </div>

                        {{-- SITEID --}}
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Site ID</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="test" name="SITEID" placeholder="Site ID"  value="{{ old('SITEID', '') }}" required="">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-2 col-form-label"></label>
                            <div class="col-sm-10">
                                <button class="btn btn-primary"> Submit </button>
                            </div>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>

</div>

@endsection
