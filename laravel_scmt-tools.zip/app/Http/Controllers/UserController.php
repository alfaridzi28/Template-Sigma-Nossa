<?php

namespace App\Http\Controllers;

use App\User;
use App\Permission as Module;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller {
    
    public function index() {
        return view('user.index', [
            'users' => User::orderBy('username')->get()
        ]);
    }

    
    public function create() {
        return view('user.create', [
            'modules'   => Module::orderBy('module')->get()
        ]);
    }

    
    public function store(Request $request) {
        request()->validate([
            'username'  => ['unique:users,username'],
            'password'  => ['required'],
            'role'      => ['required', 'in:superadmin,admin,user'],
        ]);

        $user                   = new User;
        $user->username         = request('username');
        $user->password         = sha1(request('password'));
        $user->description      = request('description');
        $user->role             = request('role');
        $user->active           = request('active');
        $user->active_reason    = request('active_reason');
        $user->module           = $user->role == 'superadmin' ? 'all' : implode(',', request('module'));

        if($user->save()){
            return redirect()->back()->with('message', 'User successfully created');
        } else {
            return redirect()->back()->with('error', 'Cannot update user at the moment');
        }
    }

    
    public function show(User $user) {
        
    }

    
    public function edit(User $user) {
        return view('user.edit', [
            'user'      => $user,
            'modules'   => Module::orderBy('module')->get()
        ]);
    }

    public function update(Request $request, User $user) {
        if(!empty(request()->password)){
            $user->password = sha1(request('password'));
        }

        $user->description      = request('description');
        $user->role             = request('role');
        $user->active           = request('active');
        $user->active_reason    = request('active_reason');
        $user->module           = implode(',', request('module'));

        if($user->update()){
            return redirect()->back()->with('message', 'User successfully updated');
        } else {
            return redirect()->back()->with('error', 'Cannot update user at the moment');
        }
    }

    public function destroy(User $user) {
        
    }

    public function auth(){
        // $user = User::where(['username' => request('username'), 'password' => sha1(request('password'))])->first();
        
        // if($user){
        if(auth()->attempt(['username' => request('username'), 'password' => sha1(request('password')), 'active' => '1'])){
            // Auth::login($user);

            return redirect('/');
        } else {
            return redirect()->back()->with('message', 'Wrong username or password');
        }
    }

    public function login(){
        return view('user.login');
    }

    public function logout(){
        auth()->logout();
        return redirect('/');
    }
}
